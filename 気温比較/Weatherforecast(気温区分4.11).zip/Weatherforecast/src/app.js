/*
* グローバル変数
*/

// チャートグラフのインスタンス
let myChart = null;

// 雨の日だったら画面表示をしない/する(true/false)
const displayOptions = {
    skipByRain: false
};


// ページが読み込まれたら自動でCSVを取得してグラフを描画する
window.addEventListener('DOMContentLoaded', async () => {
    await createCheckBoxes();
    document.getElementById("analyzeBtn").addEventListener("click", analyzeSelected);

    document.getElementById("selectAllBtn").addEventListener("click", selectAllFiles);

    document.getElementById("clearAllBtn").addEventListener("click", clearAllFiles);

    document.getElementById("monthSelectAllBtn").addEventListener("click", monthSelectAll);

    document.getElementById("monthClearAllBtn").addEventListener("click", monthClearAll);
    
    document.getElementById("skipByRain").addEventListener("click", switchSkipByRain);
});


async function createCheckBoxes() {
    try {
        // CSV一覧取得
        const csvFiles = await fetch('http://localhost:8989/api/get-csv-list').then(res => res.json());
        //console.log("取得対象:", csvFiles);
        
        // 選択ボタン
        const area = document.getElementById("fileList");
        area.innerHTML = "";
        csvFiles.forEach(file => {
            area.insertAdjacentHTML(
                "beforeend",
                `
                <label>
                <input
                    type="checkbox"
                    value="${file}">
                ${file.replace(".csv", "")}
            </label>
                `
            );
        });
    } catch (err) {
        console.error(err);
        alert("CSV一覧取得失敗");
    }
}


async function analyzeSelected() {
    try {
        const selectedFiles = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value);
        if (selectedFiles.length === 0) {
            alert("CSVを選択してください");
            return;
        }

        const selectedMonths = getSelectedMonths();
        if (selectedMonths.length === 0) {
            alert("表示月を選択してください");
            return;
        }

        // 選択された年度CSV取得
        const selectedYearData = [];

        for (const file of selectedFiles) {
            //console.log(`${file} 読込開始`);

            const buffer = await fetch(`http://localhost:8989/api/get-csv-text?file=${encodeURIComponent(file)}`).then(res => res.arrayBuffer());

            // Shift_JIS対応
            const decoder = new TextDecoder('shift-jis');
            const csvText = decoder.decode(buffer);

            // ヘッダ行検出
            const lines = csvText.split(/\r?\n/);
            const headerIndex = lines.findIndex(line => line.includes("年月日時"));

            if (headerIndex < 0) {
                console.warn(`${file} にヘッダが見つかりません`);
                continue;
            }

            // ヘッダ補正
            lines[headerIndex] = "年月日時,気温(℃),気温_品質情報,気温_均質番号,天気,天気_品質情報,天気_均質番号,降水量(mm),降水量_現象なし情報,降水量_品質情報,降水量_均質番号";

            /*
            ヘッダ情報
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            |                 0|        1 |             2 |             3 |    4 |             5 |             6 |          7 |                   8 |               9 |              10 |←インデックス番号
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            | 年月日時         | 気温(℃) | 気温(℃)      | 気温(℃)      | 天気 | 天気          | 天気          | 降水量(mm) | 降水量(mm)          | 降水量(mm)      | 降水量_均質番号 |←オリジナル
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            |                  |          | 品質情報      | 均質番号      |      | 品質情報      | 均質番号      |            | 現象なし情報        | 品質情報        | 均質番号        |←オリジナル
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            | 年月日時         | 気温(℃) | 気温_品質情報 | 気温_均質番号 | 天気 | 天気_品質情報 | 天気_均質番号 | 降水量(mm) | 降水量_現象なし情報 | 降水量_品質情報 | 降水量_均質番号 |←ヘッダ補正
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            | 2026/9/8 1:00:00 |     24.2 |             8 |             1 |   10 |             8 |             1 |        0.0 |                   0 |               8 |               1 |←サンプル
            |------------------|----------|---------------|---------------|------|---------------|---------------|------------|---------------------|-----------------|-----------------|
            */

            const fixedCsv = lines.slice(headerIndex).join("\n");

            // デバッグ用コンソール表示
            //console.log(fixedCsv);

            const parsed = Papa.parse(fixedCsv,
                            {
                                header: true,
                                skipEmptyLines: true
                            }
            );

            // デバッグ用コンソール表示
            //console.log('▼CSVパース▼');
            //console.log(parsed);

            const validData = parsed.data.filter(row => row["年月日時"]);

            // デバッグ用コンソール表示
            //console.log('デバッグ用コンソール表示【validData】');
            //console.log(validData);

            // 最終行補正
            const lastRow = validData[validData.length - 1];

            if ( lastRow &&
                 lastRow["年月日時"] &&
                 lastRow["年月日時"].endsWith("00:00:00") ) {

                const dt = new Date(lastRow["年月日時"]);

                dt.setDate(dt.getDate() - 1);

                const year = dt.getFullYear();
                const month = dt.getMonth() + 1;
                const day = dt.getDate();

                lastRow["年月日時"] = `${year}/${month}/${day} 24:00:00`;
            }

            // 日最高気温集計
            const dailyMaxTemps = calcDailyMaxTemp(validData);

            // デバッグ用コンソール表示
            //console.log('デバッグ用コンソール表示【dailyMaxTemps】');
            //console.log(dailyMaxTemps);
            
            
            // 選択月の範囲にフィルター
            const filteredData = filterByMonth(validData, dailyMaxTemps, selectedMonths);
            console.log('☆☆filteredData☆☆');
            console.log(filteredData);
            
            
            // 1時間ごとのデータから「日ごとの天気」を取得する
            const dailyWeather = createDailyWeather(filteredData.weatherData);

            // map{key:value, ...}に変換してからfilteredDataにdailyWeatherをがっちゃんこ
            const weatherMapByDate = {};
            dailyWeather.forEach(item => {
                weatherMapByDate[item.date] = item.weather;
            });

            // filteredDataに対してマージする
            const mergedData = filteredData.dailyMaxTemps.map(item => {
                return {
                    date: item.date,
                    maxTemp: item.maxTemp,
                    weather: weatherMapByDate[item.date]
                };

            });
            

            selectedYearData.push({
                year: file.replace(".csv", ""), // CSVファイル名から西暦を取得
                data: mergedData // 最高気温＆天気
                //data: filteredData.dailyMaxTemps, // 日ごとの最高気温（選択月でフィルター済み）
                //weatherData: dailyWeather
            });

            // デバッグ用コンソール表示
            console.log('デバッグ用コンソール表示【selectedYearData】');
            console.log(selectedYearData);

            //console.log(`${file} 読込完了`);
        }

        // デバッグ用コンソール表示
        //console.log('▼▼▼selectedYearData▼▼▼');
        //console.log(selectedYearData);
        //selectedYearData.forEach(yearData => {
        //    console.log(
        //        yearData.year,
        //        yearData.data.length
        //    );
        //});

        // グラフ描画
        drawChart(selectedYearData, selectedMonths);



        // 同一の年月で最高気温のランキングを作成する
        // オブジェクト(月別の最高気温情報)の作成
        const rankingMap = getTempRanking(selectedYearData);
        //console.log('rankingMap',rankingMap); //オブジェクト(月別の最高気温情報)の確認

        // オブジェクト(月別の最高気温カウント)の作成
        const monthlyCount = getMonthlyTopTempCount(rankingMap);
        //console.log('monthlyCount',monthlyCount); //オブジェクト(月別の最高気温カウント)の確認


        // 選択された年度データから月別の平均値・中央値を生成する
        const stats = createStats(selectedYearData);
        //console.log('▼▼▼月別の平均値・中央値▼▼▼');
        //console.log(stats);
        
        
        // 高温日区分を返す関数（夏用）
        const categoryCount = getCategoryCount(selectedYearData); // 気温区分（真夏日・猛暑日・酷暑日）ごとの件数
        //console.log('▽▽▽気温区分（真夏日・猛暑日・酷暑日）ごとの件数▽▽▽');
        //console.log(categoryCount);
        



        
        // 最高気温の表を作成し、HTMLへ渡す
        createMaxTable(monthlyCount, stats, categoryCount);




    } catch (err) {
        console.error(err);
    }
}
//let myChart = null;



/**
 * 1時間ごとのデータから「日ごとの最高気温」を計算する関数
 */
function calcDailyMaxTemp(data) {
    const dailyMap = {};

    data.forEach(row => {
        const datetimeStr = row['年月日時']; // 例: "2020/1/1 1:00:00"
        const tempStr = row['気温(℃)'];     // 例: "4.0"

        if (!datetimeStr || tempStr === undefined || tempStr === '') return;

        const datePart = datetimeStr.split(' ')[0];
        const temp = parseFloat(tempStr);

        if (isNaN(temp)) return;

        if (!(datePart in dailyMap)) {
            dailyMap[datePart] = temp;
        } else {
            if (temp > dailyMap[datePart]) {
                dailyMap[datePart] = temp;
            }
        }
    });

    const resultArray = Object.keys(dailyMap).map(date => {
        return {
            date: date,
            maxTemp: dailyMap[date]
        };
    });

    return resultArray;
}


// 日ごとの最高気温の表を作成
/**
function drawTable(data) {

    const tbody =
        document.querySelector("#tempTable tbody");

    tbody.innerHTML = "";
    const columns = 4;

    for (let i=0; i < data.length; i+=columns) {
        const tr = document.createElement("tr");
        let html = "";

        for (let j=0; j<columns; j++) {
            const row = data[i + j];

            if (row) {
                html += `
                    <td>${row.date}</td>
                    <td>${row.maxTemp}</td>
                `;
            } else {
                html += `
                    <td></td>
                    <td></td>
                `;
            }
        }
        tr.innerHTML = html;
        tbody.appendChild(tr);
    }
}
 */


/**
 * Chart.jsでグラフを描画する関数
 */
function drawChart(selectedYearData) {

    const colors = [
        "#ff0000",
        "#0066ff",
        "#00aa00",
        "#ff9900",
        "#9900cc",
        "#00cccc",
        "#cc3366",
        "#888888",
        "#ff6699",
        "#3399ff",
        "#66cc00"
    ];

    // 選択中の月
    const selectedMonths = Array.from(
        document.querySelectorAll('#monthList input[type="checkbox"]:checked')
    ).map(e => parseInt(e.value, 10));

    // ラベル準備
    const labels = [];
    selectedYearData.forEach(yearData => {
        yearData.data.forEach(item => {
            // 雨の日はカウント対象にするのか判定
            if (displayOptions.skipByRain) {
                if (item.weather === weatherMap[10]) {
                    // 雨の日の場合はスキップ
                    return;
                } else {
                    // 雨の日以外はスキップしない
                    const parts = item.date.split('/');
                    const monthDay = `${parseInt(parts[1], 10)}/${parseInt(parts[2], 10)}`;

                    labels.push(monthDay);
                }
            } else {
                const parts = item.date.split('/');
                const monthDay = `${parseInt(parts[1], 10)}/${parseInt(parts[2], 10)}`;

                labels.push(monthDay);
            }
        });
    });
    const uniqueLabels = sortByMonthDay(labels);

    // データセット
    const datasets = selectedYearData.map((yearData, index) => {

        // 月日 → 気温 のMap作成
        const dataMap = {};
        
        yearData.data.forEach(item => {
            
            // 雨の日はカウント対象にするのか判定
            if (displayOptions.skipByRain) {
                if (item.weather === weatherMap[10]) {
                    // 雨の日の場合はスキップ
                    return;
                } else {
                    // 雨の日以外はスキップしない
                    const parts = item.date.split('/');
                    const monthDay = `${parseInt(parts[1], 10)}/${parseInt(parts[2], 10)}`;
                    dataMap[monthDay] = Number(item.maxTemp);
                }
            
            } else {
                const parts = item.date.split('/');
                const monthDay = `${parseInt(parts[1], 10)}/${parseInt(parts[2], 10)}`;
                dataMap[monthDay] = Number(item.maxTemp);
            }
        });

        return {
            label: yearData.year,
            data: uniqueLabels.map(label => dataMap[label] ?? null),
            borderColor: colors[index % colors.length],
            backgroundColor: colors[index % colors.length],
            borderWidth: 1,
            pointRadius: 0,
            pointHoverRadius: 3,
            fill: false,
            tension: 0,
            spanGaps: false
        };
    });

    const ctx = document.getElementById('tempChart').getContext('2d');

    if (myChart) {
        myChart.destroy();
    }
    myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: uniqueLabels,
            datasets: datasets
        },

        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                title: {
                    display: true,
                    text: '年度別 日最高気温比較'
                },
                legend: {
                    display: true
                }
            },
            scales: {
                x: {
                    type: 'category',
                    title: {
                        display: true,
                        text: '月日'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: '気温(℃)'
                    },
                    ticks: {
                        //autoSkip: false
                        //autoSkip: true
                        //maxTicksLimit: 90
                    }
                }
            }
        }
    });
}


// 選択した月の取得
function getSelectedMonths() {
    const checkboxes = document.querySelectorAll('#monthList input[type="checkbox"]:checked');
    return Array.from(checkboxes).map(e => parseInt(e.value, 10));
}

/**
 * 指定した月のデータにフィルター
 * @param {Array} validData      1時間ごとの気象データ（1年分）
 * @param {Array} dailyMaxTemps  日最高気温データ
 * @param {Array} selectedMonths 選択された月（例：[6, 7, 8]）
 * @returns {Object}
 */
// 選択月の範囲にフィルター（csvファイルと選択中の月(selectedMonths)と比較して合致したものだけ返すことでフィルター）
function filterByMonth(validData, dailyMaxTemps, selectedMonths) {
    
    // 最高気温のフィルター
    const filteredDailyMaxTemps = dailyMaxTemps.filter(item => {

        // 日付(YYYY/MM/DD)から月を取得
        const parts = item.date.split('/');
        const month = parseInt(parts[1], 10);
        
        // 選択月に含まれている最高気温のみ返却
        return selectedMonths.includes(month);
    });


    // 天気データのフィルター
    const filteredValidData = validData.filter(item => {
        
        // 日付時刻(YYYY/MM/DD HH:mm:ss)から月を取得
        const parts = item["年月日時"].split('/');
        const month = parseInt(parts[1], 10);

        // 選択月に含まれているデータのみ返却
        return selectedMonths.includes(month);
    });

    // オブジェクトで返却
    return {
        dailyMaxTemps: filteredDailyMaxTemps,
        weatherData: filteredValidData
    };

}


// csvファイル選択チェックボックス制御
function selectAllFiles() {

    document.querySelectorAll('#fileList input[type="checkbox"]')
        .forEach(chk => {
            chk.checked = true;
        });
}
function clearAllFiles() {

    document.querySelectorAll('#fileList input[type="checkbox"]')
        .forEach(chk => {
            chk.checked = false;
        });
}

// 月選択チェックボックス制御
function monthSelectAll() {

    document.querySelectorAll('#monthList input[type="checkbox"]')
        .forEach(chk => {chk.checked = true;});
}

function monthClearAll() {

    document.querySelectorAll('#monthList input[type="checkbox"]')
        .forEach(chk => {chk.checked = false;});
}

// 雨の日は集計しないボタン
function switchSkipByRain() {
    
    // チェックボックスの状態を取得
    const skipByRainCheckbox = document.getElementById("skipByRain");
    
    // フラグへ反映
    displayOptions.skipByRain = skipByRainCheckbox.checked;
    
    //console.log(displayOptions.skipByRain);

}



// 同月日で年度別の気温ランキングを作成（2025/7/1→1位、2026/7/1→2位、2024/7/1→3位みたいな）
function getTempRanking(selectedYearData) {

    // 月日ごとの気温データを格納する連想配列
    /* 
    *例:
    * {
    *   "08/31": [
    *     { year: 2023, date: "2023/08/31", temp: 35.0 },
    *     { year: 2024, date: "2024/08/31", temp: 33.5 }
    *   ]
    * }
    */
    const rankingMap = {};

    // ①年別、同月日にまとめる（2026/7/1、2025/7/1、2024/7/1みたいな）
    // 選択された各年のデータを走査
    selectedYearData.forEach(yearData => {

        // その年の日別データを走査
        yearData.data.forEach(item => {

            // 雨の日は集計対象にするか判定
            if (displayOptions.skipByRain) {
            
                // 雨の日は集計をスキップする
                if (item.weather === weatherMap[10]) { return }
                else {
                    // 雨の日以外の天気のみ集計する
                    // 日付(YYYY/MM/DD)から月日(MM/DD)を抽出（ex：7/1）
                    const parts = item.date.split('/');
                    const monthDay = `${parts[1]}/${parts[2]}`;
                    //console.log('monthDay',monthDay); //デバッグ確認用
                    
                    // MM/DD月日のキーが未作成の場合は配列を初期化作成（ex：rankingMap[7/1]=undefinedならrankingMap[7/1]という配列を作成）
                    // 初年度は作成するが、2年目以降は作成済みの配列を利用する
                    if (!rankingMap[monthDay]) {
                        rankingMap[monthDay] = [];
                    }
                    
                    // ランキング判定に必要な情報を格納
                    rankingMap[monthDay].push({
                        // 指定したキーに対して、格納していく
                        year: yearData.year, // 年
                        date: item.date,     // 日付
                        temp: item.maxTemp   // 最高気温
                    });
                    
                
                }
            
            } else {
                // 通常通り、雨の日でも集計する
                // 日付(YYYY/MM/DD)から月日(MM/DD)を抽出（ex：7/1）
                const parts = item.date.split('/');
                const monthDay = `${parts[1]}/${parts[2]}`;
                //console.log('monthDay',monthDay); //デバッグ確認用
            
                // MM/DD月日のキーが未作成の場合は配列を初期化作成（ex：rankingMap[7/1]=undefinedならrankingMap[7/1]という配列を作成）
                // 初年度は作成するが、2年目以降は作成済みの配列を利用する
                if (!rankingMap[monthDay]) {
                    rankingMap[monthDay] = [];
                }

                // ランキング判定に必要な情報を格納
                rankingMap[monthDay].push({
                    // 指定したキーに対して、格納していく
                    year: yearData.year, // 年
                    date: item.date,     // 日付
                    temp: item.maxTemp   // 最高気温
                });
            
            
            }
        
        });
        
    });

    // ②用意したrankingMapを基に、月日ごとにランキングを作成
    // monthDayキーを基準に’月日ごと’回す
    Object.keys(rankingMap).forEach(monthDay => {

        // 最高気温の降順でソート（マイナス → aを前へ、プラス → bを前へ）
        rankingMap[monthDay].sort(
            (a, b) => b.temp - a.temp
        );

        // ソート順に順位を付与※ソート後index番号を利用して順位を付与
        rankingMap[monthDay].forEach((item, index) => {
            item.rank = index + 1;
        });
    });

    //console.log('rankingMap',rankingMap); //デバッグ確認用
    return rankingMap;
}

/**
 * 月ごとの最高気温獲得日数を集計する
 *
 * @param {Object} rankingMap 日別最高気温ランキング
 * @returns {Object} 月別・年別の最高気温獲得日数
*/
function getMonthlyTopTempCount(rankingMap) {

    // 選択中の年のみ取得
    //const selectedYears = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value);
    const selectedYears = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value.replace(".csv", ""));

    // 月ごと・年ごとの最高気温獲得日数を用意
    const monthlyCount = {};

    // 日付(MM/DD)ごとに処理
    Object.keys(rankingMap).forEach(monthDay => {

        // 月を取得("07/01" → "07")
        const month = monthDay.split('/')[0];

        // 月の集計領域を作成
        // 月の集計領域が存在しなければ作成(例: monthlyCount["07"] = {})
        if (!monthlyCount[month]) {
            monthlyCount[month] = {};

            // 選択された年を0で初期化
            selectedYears.forEach(year => {
                monthlyCount[month][year] = 0;
            });
        }

        // その日の最高気温(配列の先頭[0]が最高気温の年となる)
        const topData = rankingMap[monthDay][0];

        // 最高気温獲得日数を加算(選択年のみカウント)
        if (topData.year in monthlyCount[month]) {
            monthlyCount[month][topData.year]++;
        }
    });


    return monthlyCount;
}


/**
 * 選択された年度データから月別の平均値・中央値を生成する
 *
 * @param {Array} selectedYearData 年度別気温データ
 * @returns {Object} stats 月別・年別の統計情報
 */
function createStats(selectedYearData) {

    const stats = {};

    selectedYearData.forEach(yearObj => {

        const year = yearObj.year;
        
        // 月ごとの気温リスト
        const monthlyTemps = {};


        yearObj.data.forEach(record => {
                
            // 雨の日は計算対象にするか判定
            if (displayOptions.skipByRain) {
                // 雨の日は計算スキップ
                if (record.weather === weatherMap[10]) { return }
                else {
                    // 雨の日以外
                    const dateParts = record.date.split('/');
                    const month = String(Number(dateParts[1]));

                    if (!monthlyTemps[month]) {
                        monthlyTemps[month] = [];
                    }
                    monthlyTemps[month].push(record.maxTemp);
                }
                
            } else {
                
                const dateParts = record.date.split('/');
                const month = String(Number(dateParts[1]));
                
                if (!monthlyTemps[month]) {
                    monthlyTemps[month] = [];
                }
                monthlyTemps[month].push(record.maxTemp);
            }
            
        });

        // 月ごとに平均・中央値を計算
        Object.keys(monthlyTemps).forEach(month => {

            const temps = monthlyTemps[month];

            const average =
                temps.reduce((sum, temp) => sum + temp, 0) /
                temps.length;

            const sortedTemps = [...temps].sort((a, b) => a - b);

            const middle = Math.floor(sortedTemps.length / 2);

            const median =
                sortedTemps.length % 2 === 0
                    ? (
                        sortedTemps[middle - 1] +
                        sortedTemps[middle]
                    ) / 2
                    : sortedTemps[middle];

            if (!stats[month]) {
                stats[month] = {};
            }

            stats[month][year] = {
                average: Number(average.toFixed(1)),
                median: Number(median.toFixed(1))
            };
        });
        

    });

    return stats;
}


/**
 * 高温日区分を取得
 *
 * @param {Array} selectedYearData
 * @returns {Object}
 */
function getCategoryCount(selectedYearData) {

    const result = {};

    // 選択した年（yearData）でforEach
    selectedYearData.forEach(yearData => {

        // 年（西暦）
        const year = yearData.year;

        // 月ごとの区分件数
        const monthlyCategoryCount = {};

        // 日（dayData）でforEach
        yearData.data.forEach(dayData => {

            // 雨の日はカウント対象にするのか判定
            if (displayOptions.skipByRain) {
                if (dayData.weather === weatherMap[10]) {
                    // 雨の場合はスキップ
                    return;
                } else {
                    // 雨の日以外
                    
                    // 処理中の日（dayData）の属する月
                    const month = String(Number(dayData.date.split('/')[1]));

                    // monthlyCategoryCount[month]の初期化（変数が未定義の場合にオブジェクト作って、0でカウント）
                    if (!monthlyCategoryCount[month]) {
                        monthlyCategoryCount[month] = {
                            "真夏日：30℃以上～35℃未満": 0,
                            "猛暑日：35℃以上～40℃未満": 0,
                            "酷暑日：40℃以上": 0
                        };
                    }

                    // 処理中の日（dayData）の最高気温
                    const temp = Number(dayData.maxTemp);

                    // 区分をカウント
                    if (temp >= 30 && temp < 35) {
                        monthlyCategoryCount[month]["真夏日：30℃以上～35℃未満"]++;
                    } else if (temp >= 35 && temp < 40) {
                        monthlyCategoryCount[month]["猛暑日：35℃以上～40℃未満"]++;
                    } else if (temp >= 40) {
                        monthlyCategoryCount[month]["酷暑日：40℃以上"]++;
                    }
                }
                
            // 通常通り
            } else {
                // 処理中の日（dayData）の属する月
                const month = String(Number(dayData.date.split('/')[1]));

                // monthlyCategoryCount[month]の初期化（変数が未定義の場合にオブジェクト作って、0でカウント）
                if (!monthlyCategoryCount[month]) {
                    monthlyCategoryCount[month] = {
                        "真夏日：30℃以上～35℃未満": 0,
                        "猛暑日：35℃以上～40℃未満": 0,
                        "酷暑日：40℃以上": 0
                    };
                }

                // 処理中の日（dayData）の最高気温
                const temp = Number(dayData.maxTemp);

                // 区分をカウント
                if (temp >= 30 && temp < 35) {
                    monthlyCategoryCount[month]["真夏日：30℃以上～35℃未満"]++;
                } else if (temp >= 35 && temp < 40) {
                    monthlyCategoryCount[month]["猛暑日：35℃以上～40℃未満"]++;
                } else if (temp >= 40) {
                    monthlyCategoryCount[month]["酷暑日：40℃以上"]++;
                }
            
            }
        });
        //console.log('▼月ごとの区分件数（monthlyCategoryCount）▼');
        //console.log("▽", year, "▽");
        //console.log(monthlyCategoryCount);
        // 月ごとの区分件数を result に格納
        
        Object.keys(monthlyCategoryCount).forEach(month => {

            // 月領域が未作成なら初期化
            if (!result[month]) {
                result[month] = {};
            }

            result[month][year] = monthlyCategoryCount[month];
        });

        
    });

    return result;
}



/**
 * 月ごとの最高気温獲得日数をHTMLへ渡し、表形式で表示
 *
 * @param {Object} monthlyCount 月別の最高気温カウント
*/
function createMaxTable(monthlyCount, stats, categoryCount) {
    const table = document.getElementById("monthlyTable");
    const tbody = table.querySelector("tbody");
    
    // 前回の表示内容を削除
    tbody.innerHTML = "";

    let hasMultiYearData = false;

    Object.keys(monthlyCount)
        .sort()
        .forEach(month => {

            // 比較する年（西暦）数
            //const selectedYears = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value).length;
            //const selectedYears = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value);
            const selectedYears = [...document.querySelectorAll('#fileList input[type="checkbox"]:checked')].map(e => e.value.replace(".csv", ""));
            //console.log('比較する年数・・・' + selectedYears.length);
            
            // 実データ
            //const yearData = Object.entries(monthlyCount[month]);
            const yearData = selectedYears.map(year => [
                year,
                monthlyCount[month]?.[year] ?? 0
            ]);
            
            

            // 2年以上なら表示対象
            if (selectedYears.length > 1) {
                hasMultiYearData = true;
                yearData.sort((a, b) => b[1] - a[1]);

                yearData.forEach(([year, count], index) => {
                    const tr = document.createElement("tr");
                    const displayYear = year.slice(0, 4);

                    // 平均値
                    const average =
                        stats?.[month]?.[year]?.average ?? "-";

                    // 中央値
                    const median =
                        stats?.[month]?.[year]?.median ?? "-";

                    // 気温区分（真夏日・猛暑日・酷暑日）ごとの件数
                    const categoryObject =
                        categoryCount?.[month]?.[year];

                    // categoryObjectが存在すれば`${name}（${count}回）` ※三項演算子（条件 ? 真の場合 : 偽の場合）
                    const categoryText = categoryObject
                        ? Object.entries(categoryObject).map(([name, count]) => `${name}（${count}回）`).join("<br>")
                        : "-";


                    if (index === 0) {
                        tr.innerHTML = `
                            <td rowspan="${yearData.length}">
                                ${month}月
                            </td>
                            <td>${displayYear}年</td>
                            <td>${count}日</td>
                            <td>${average}℃</td>
                            <td>${median}℃</td>
                            <td>${categoryText}</td>
                        `;
                    } else {
                        tr.innerHTML = `
                            <td>${displayYear}年</td>
                            <td>${count}日</td>
                            <td>${average}℃</td>
                            <td>${median}℃</td>
                            <td>${categoryText}</td>
                        `;
                    }

                    tbody.appendChild(tr);
                });
            }
        });

    // 表示対象がなければテーブルごと隠す
    table.style.display = hasMultiYearData ? "table" : "none";
}



/**
 * 1時間ごとのデータから「日ごとの天気」を取得する関数
 */
function createDailyWeather(weatherData) {
    const dailyMap = {};

    weatherData.forEach(row => {

        // 年月日時
        const datetime = row['年月日時']; // 例: "2020/1/1 1:00:00"
        
        // 天気コード
        const weatherNum = row['天気'];     // 例: "1"
        
        // 天気名称
        const weather = weatherMap[weatherNum];    // 例: "快晴"

        // 取得できなければスキップ
        if (!datetime || weatherNum === undefined || weatherNum === '' || weather === undefined || weather === '') return;

        // 年月日
        const datePart = datetime.split(' ')[0]; // 例: "2020/1/1"

        // 日付キー(dailyMap[datePart])に天気を設定して初期化
        if (!(datePart in dailyMap)) { // 最初に定義したオブジェクト（連想配列）dailyMapに[datePart]キー（"2020/1/1"など日付）が無い場合
            // その日の最初の天気
            dailyMap[datePart] = weather; // キー：バリューというかオブジェクト作成
        } else {
            // その日の2回目以降の天気を評価
            
            // 天気が"雨"ならスキップ>>次の日付の天気の評価へ
            if (dailyMap[datePart] === weatherMap[10]) {
                return;
            
            // 同じ天気ならスキップ>>次の時間の天気の評価へ
            } else if (dailyMap[datePart] === weather) {
                // 同じ日付で、天気が変わらない
                return;
            
            // 異なる天気なら、その天気を評価
            } else {

                // 登録中の天気 => 雨であればスキップ。
                if (weather === weatherMap[10]) {
                    // その日の天気は'雨'で決定させてしまう
                    dailyMap[datePart] = weather;
                    //console.log('日付(yyyy/MM/dd)', datePart);
                    //console.log('天気', dailyMap[datePart]);
                    //console.log('>>>次の日へ>>>');
                    return;
                
                } else if (weather === weatherMap[12]) {
                    // 一応'雪'も同じように決定させる。夏を対象にしたいから蛇足だけど
                    dailyMap[datePart] = weather;
                    //console.log('日付(yyyy/MM/dd)', datePart);
                    //console.log('天気', dailyMap[datePart]);
                    //console.log('>>>次の日へ>>>');
                    return;
                
                } else {
                    // その日の2回目以降の新しい天気に更新
                    dailyMap[datePart] = weather;
                
                }
            
            }
            
        }
    });

    // 日付ごとの天気を配列に変換
    const resultArray = Object.keys(dailyMap).map(dateItem => {
        return {
            date: dateItem,
            weather: dailyMap[dateItem]
        };
    });
    
    //console.log('createDailyWeather▽結果▽');
    //console.log(resultArray);

    return resultArray;
}

function sortByMonthDay(values) {
    return [...new Set(values)].sort((a, b) => {
        const [monthA, dayA] = a.split('/').map(Number);
        const [monthB, dayB] = b.split('/').map(Number);

        if (monthA !== monthB) {
            return monthA - monthB;
        }

        return dayA - dayB;
    });
}







// 天気（インデックス番号：4）
const weatherMap = {
    "1": "快晴",
    "2": "晴れ",
    "3": "薄曇",
    "4": "曇",
    "5": "煙霧",
    "6": "砂じん嵐",
    "7": "地ふぶき",
    "8": "霧",
    "9": "霧雨",
    "10": "雨",
    "11": "みぞれ",
    "12": "雪",
    "13": "あられ",
    "14": "ひょう",
    "15": "雷",
    "16": "しゅう雨",
    "17": "着氷性の雨",
    "18": "着氷性の霧雨",
    "19": "しゅう雪",
    "20": "霧雪",
    "21": "凍雨",
    "22": "細氷",
    "23": "もや",
    "24": "降水"
};


// 品質情報（インデックス番号：2, 5, 9）
const qualityMap = {
    "8": "正常値",
    "5": "準正常値",
    "4": "資料不足値",
    "3": "疑問値",
    "2": "利用不適値",
    "1": "資料なし、未報告、欠測",
    "0": "観測対象外"
};

// 現象なし情報（インデックス番号：8）
const rainStatus = {
    "0": "現象あり",
    "1": "現象なし",
    "": "対象外"
};