const keyStr = "CBZ!\"#$%&\'()*+,-./0123456789:;<=";
const ivStr = "CBZ>?@[\\]^_`{|}~";

// =========================
// 変換系ユーティリティ
// Shift_JIS変換（追加）
// =========================
function strToSjisUint8(str) {
  const unicodeArray = Encoding.stringToCode(str);
  const sjisArray = Encoding.convert(unicodeArray, {
    to: "SJIS",
    from: "UNICODE"
  });
  return new Uint8Array(sjisArray);
}

// =========================
// Base64系
// =========================
function sjisUint8ToStr(bytes) {
  const unicodeArray = Encoding.convert(Array.from(bytes), {
    to: "UNICODE",
    from: "SJIS"
  });
  return Encoding.codeToString(unicodeArray);
}

function uint8ToBase64(bytes) {
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary);
}

function base64ToUint8(base64) {
  const binary = atob(base64.trim());
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// =========================
// デバッグ表示（HEX）
// =========================
function toHex(bytes) {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, "0"))
    .join(" ");
}

function pkcs7Pad(data, blockSize = 16) {
  const len = data.length;

  console.log("---- PKCS7 PAD DEBUG ----");
  console.log("元データ長:", len);

  // パディング長計算
  let padLength = blockSize - (len % blockSize);

  // ★重要：ピッタリの場合も1ブロック追加
  if (padLength === 0) {
    padLength = blockSize;
  }

  console.log("padLength:", padLength);

  const padding = new Uint8Array(padLength).fill(padLength);

  console.log("パディング:", toHex(padding));

  const result = new Uint8Array(len + padLength);
  result.set(data);
  result.set(padding, len);

  console.log("結果長:", result.length);
  console.log("最終ブロック:", toHex(result.slice(-16)));

  // ✅ 検証：最後が揃っているかチェック
  for (let i = result.length - padLength; i < result.length; i++) {
    if (result[i] !== padLength) {
      console.error("❌ パディング生成ミス");
    }
  }

  console.log("✅ パディング生成OK");

  return result;
}

// =========================
// PKCS7アンパディング
// =========================
function pkcs7Unpad(data) {
  const len = data.length;

  if (len === 0) {
    throw new Error("データ長0");
  }

  const padLength = data[len - 1];

  console.log("---- PKCS7 DEBUG ----");
  console.log("全体長:", len);
  console.log("padLength:", padLength);
  console.log("復号RAW:", toHex(data));
  console.log("末尾16バイト:", toHex(data.slice(-16)));

  if (padLength < 1 || padLength > 16) {
    console.error("❌ padLength範囲外");
    throw new Error("パディング不正（範囲外）");
  }

  const padding = data.slice(len - padLength);
  console.log("パディング部分:", toHex(padding));

  for (let i = 0; i < padding.length; i++) {
    if (padding[i] !== padLength) {
      console.error(`❌ パディング不一致 index=${i}`);
      console.log("期待:", padLength, "実際:", padding[i]);
      throw new Error("パディング不正（一致しない）");
    }
  }

  console.log("✅ パディング正常");

  return data.slice(0, len - padLength);
}

// =========================
// 暗号化
// =========================
async function encrypt() {
  console.log("====== 暗号化開始 ======");

  const text = document.getElementById("inputText").value;
  console.log("平文:", text);

  // SJISに変更
  const data = strToSjisUint8(text);
  console.log("平文(SJIS):", toHex(data), "len=", data.length);

  //const padded = pkcs7Pad(data);
  //console.log("パディング後:", toHex(padded), "len=", padded.length);

  const keyBytes = strToSjisUint8(keyStr);
  const ivBytes = strToSjisUint8(ivStr);

  console.log("KEY:", keyStr);
  console.log("KEY bytes:", toHex(keyBytes), "len=", keyBytes.length);

  console.log("IV:", ivStr);
  console.log("IV bytes:", toHex(ivBytes), "len=", ivBytes.length);

  if (keyBytes.length !== 32) {
    console.error("❌ KEYは32バイト必要（AES-256）");
  }

  if (ivBytes.length !== 16) {
    console.error("❌ IVは16バイト必要");
  }

  const key = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "AES-CBC" },
    false,
    ["encrypt"]
  );

  const encryptedBuffer = await crypto.subtle.encrypt(
    { name: "AES-CBC", iv: ivBytes },
    key,
    //padded
    data
  );

  const encryptedBytes = new Uint8Array(encryptedBuffer);

  console.log("暗号文(HEX):", toHex(encryptedBytes));

  const base64 = uint8ToBase64(encryptedBytes);

  console.log("Base64:", base64);

  document.getElementById("output").value = base64;

  console.log("====== 暗号化終了 ======");
}

// =========================
// 復号
// =========================
async function decrypt() {
  console.log("====== 復号開始 ======");

  const base64 = document.getElementById("inputText").value;

  console.log("入力(Base64):", base64);

  const encryptedBytes = base64ToUint8(base64);
  console.log("暗号文長:", encryptedBytes.length);
  console.log("暗号バイト:", toHex(encryptedBytes), "len=", encryptedBytes.length);

  if (encryptedBytes.length % 16 !== 0) {
    console.error("❌ 暗号文の長さが16の倍数ではない");
  }

  const keyBytes = strToSjisUint8(keyStr);
  const ivBytes = strToSjisUint8(ivStr);

  console.log("KEY bytes:", toHex(keyBytes), "len=", keyBytes.length);
  console.log("IV bytes:", toHex(ivBytes), "len=", ivBytes.length);

  if (keyBytes.length !== 32) {
    console.error("❌ KEY長不正");
  }

  if (ivBytes.length !== 16) {
    console.error("❌ IV長不正");
  }

  const key = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "AES-CBC" },
    false,
    ["decrypt"]
  );

  let decryptedBuffer;

  try {
    decryptedBuffer = await crypto.subtle.decrypt(
      { name: "AES-CBC", iv: ivBytes },
      key,
      encryptedBytes
    );
  } catch (e) {
    console.error("❌ decrypt失敗:", e);
    document.getElementById("output").value = "復号失敗（鍵またはデータ不正）";
    return;
  }

  const decryptedBytes = new Uint8Array(decryptedBuffer);

  console.log("復号結果(raw):", toHex(decryptedBytes), "len=", decryptedBytes.length);

  // パディング無しなのでそのまま使う
  let unpadded = decryptedBytes;

  //try {
  //  unpadded = pkcs7Unpad(decryptedBytes);
  //} catch (e) {
  //  console.error("❌ パディングエラー:", e);
  //  document.getElementById("output").value = "パディングエラー";
  //  return;
  //}

  //console.log("パディング除去後:", toHex(unpadded));
  console.log("パディング無し:", toHex(unpadded));

  //const text = uint8ToStr(unpadded);
  const text = sjisUint8ToStr(unpadded);

  console.log("復号文字列:", text);

  document.getElementById("output").value = text;

  console.log("====== 復号終了 ======");
}